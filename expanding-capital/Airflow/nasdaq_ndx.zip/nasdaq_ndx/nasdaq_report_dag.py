from airflow import DAG
from airflow.operators.python import PythonOperator
from datetime import datetime, timedelta
import smtplib
from email.mime.text import MIMEText
import yfinance as yf
from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from bs4 import BeautifulSoup
import time
import os
from dotenv import load_dotenv

# Carrega as variáveis do .env
load_dotenv(dotenv_path="/opt/airflow/.env")

default_args = {
    'owner': 'airflow',
    'start_date': datetime(2025, 5, 13),
    'retries': 1,
    'retry_delay': timedelta(minutes=10),
}

dag = DAG(
    'nasdaq_report_email',
    default_args=default_args,
    description='Send NDX/NASDAQ close + PE ratio via email',
    schedule_interval='0 10 * * 1,3,5',  # Seg, Qua, Sex às 10h
    catchup=False,
    tags=['nasdaq'],
)

def send_email_report():
    # ---------- PE Ratio (via Selenium + BeautifulSoup) ----------
    chrome_options = Options()
    chrome_options.add_argument("--headless")
    chrome_options.add_argument("--no-sandbox")
    chrome_options.add_argument("--disable-dev-shm-usage")
    driver = webdriver.Chrome(options=chrome_options)

    driver.get("https://www.gurufocus.com/economic_indicators/6778/nasdaq-100-pe-ratio")
    time.sleep(5)
    html = driver.page_source
    driver.quit()

    soup = BeautifulSoup(html, "html.parser")
    table = soup.find("table", {"id": "non-sticky-table"})
    tbody = table.find("tbody")
    first_row = tbody.find("tr")
    ndx_value = first_row.find_all("td")[1].text.strip()
    ndx_pe_ratio_rounded = round(float(ndx_value), 3)

    # ---------- Fechamentos via yfinance ----------
    ndx_close = yf.Ticker("^NDX").history(period="1d")["Close"].iloc[-1]
    nasdaq_close = yf.Ticker("^IXIC").history(period="1d")["Close"].iloc[-1]
    ndx_close_rounded = round(ndx_close, 3)
    nasdaq_close_rounded = round(nasdaq_close, 3)

    # ---------- Envio de e-mail ----------
    sender_email = os.getenv("SMTP_EMAIL")
    receiver_email = os.getenv("SMTP_TO")
    password = os.getenv("SMTP_PASSWORD")
    your_name = "Rafael"
    today_str = datetime.today().strftime("%B %d, %Y")

    subject = f"NDX & NASDAQ Closing Values – {today_str}"
    body = f"""Hi team,

Here are the latest closing values for {today_str}:

• NDX (Nasdaq-100): {ndx_close_rounded}
• NASDAQ Composite: {nasdaq_close_rounded}
• NASDAQ PE Ratio: {ndx_pe_ratio_rounded}

Let me know if you'd like this data in any additional format or with historical comparisons.

Best regards,  
{your_name}
"""

    msg = MIMEText(body)
    msg["Subject"] = subject
    msg["From"] = sender_email
    msg["To"] = receiver_email

    with smtplib.SMTP_SSL("smtp.gmail.com", 465) as server:
        server.login(sender_email, password)
        server.send_message(msg)
        print("E-mail enviado com sucesso!")

t1 = PythonOperator(
    task_id='send_nasdaq_email',
    python_callable=send_email_report,
    dag=dag,
)
